package com.codingapi.tm.netty.service.impl;

import com.codingapi.tm.netty.service.IActionService;
import org.springframework.stereotype.Service;

/**
 * 补偿回调
 * create by lorne on 2017/11/11
 */
@Service(value = "c")
public class ActionCServiceImpl extends BaseSignalTaskService implements IActionService {


}
