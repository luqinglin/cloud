package com.codingapi.tm.api.service;

import com.codingapi.tm.model.ModelInfo;

import java.util.List;

/**
 * create by lorne on 2017/11/13
 */
public interface ApiModelService {

    List<ModelInfo> onlines();


}
