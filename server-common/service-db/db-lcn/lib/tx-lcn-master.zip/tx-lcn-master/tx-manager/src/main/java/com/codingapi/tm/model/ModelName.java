

package com.codingapi.tm.model;

/**
 * create by lorne on 2017/11/22
 */
public class ModelName {

    private String name;
    private int count;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }
}
