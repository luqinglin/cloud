package com.codingapi.tx.config.service;

/**
 * create by lorne on 2017/11/18
 */
public interface TxManagerTxUrlService {

    String getTxUrl();
}
