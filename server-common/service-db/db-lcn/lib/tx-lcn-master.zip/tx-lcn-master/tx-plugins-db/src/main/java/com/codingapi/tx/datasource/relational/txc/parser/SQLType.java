package com.codingapi.tx.datasource.relational.txc.parser;

/**
 *
 */
public enum SQLType {
    SELECT(),
    UPDATE(),
    INSERT(),
    DELETE(),
    UNKNOW();
}
