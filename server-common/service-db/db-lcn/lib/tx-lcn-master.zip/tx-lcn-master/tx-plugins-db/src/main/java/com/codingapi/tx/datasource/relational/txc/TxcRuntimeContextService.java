package com.codingapi.tx.datasource.relational.txc;


import com.codingapi.tx.datasource.relational.txc.parser.TxcRuntimeContext;

/**
 * @author jsy.
 * 17/12/7.
 */
public interface TxcRuntimeContextService {

    TxcRuntimeContext getTxcRuntimeContext();

}
