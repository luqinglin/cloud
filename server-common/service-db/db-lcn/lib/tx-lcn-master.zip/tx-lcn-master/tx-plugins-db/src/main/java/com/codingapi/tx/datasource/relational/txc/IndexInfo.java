package com.codingapi.tx.datasource.relational.txc;

/**
 * [类描述]
 *
 * @author caican
 * @date 17/12/23
 */
public class IndexInfo {
}
